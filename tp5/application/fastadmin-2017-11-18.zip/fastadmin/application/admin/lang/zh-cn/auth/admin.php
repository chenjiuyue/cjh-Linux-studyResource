<?php

return [
    'Group'      => '所属组别',
    'Login time' => '最后登录',
];
